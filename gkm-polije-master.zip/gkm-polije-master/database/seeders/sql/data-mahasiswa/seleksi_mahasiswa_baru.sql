-- ----------------------------
-- Records of seleksi_mahasiswa_baru
-- ----------------------------
INSERT INTO `seleksi_mahasiswa_baru` VALUES (1, 5, 8, 'TS-3', 90, 229, 106, 57, NULL, 52, NULL, NULL, NOW(), NOW());
INSERT INTO `seleksi_mahasiswa_baru` VALUES (2, 5, 8, 'TS-2', 90, 229, 106, 61, NULL, 98, NULL, NULL, NOW(), NOW());
INSERT INTO `seleksi_mahasiswa_baru` VALUES (3, 5, 8, 'TS-1', 90, 108, 79, 39, NULL, 137, NULL, NULL, NOW(), NOW());
