-- ----------------------------
-- Records of ewmp_dosen
-- ----------------------------
INSERT INTO `ewmp_dosen` VALUES (1, 1, 'Rani Purbaningtyas, S.Kom, M.T', 1, 20.75, NULL, NULL, 9.30, 0.00, 1.25, 31.30, 15.65, NULL, '2024-10-28 00:49:49', '2024-10-28 00:49:49');
INSERT INTO `ewmp_dosen` VALUES (2, 1, 'Sholihah Ayu Wulandari, S.ST, M.Tr.T.', 1, 19.15, NULL, NULL, 5.88, 4.50, 1.75, 31.28, 15.64, NULL, '2024-10-28 01:02:51', '2024-10-28 01:02:51');
INSERT INTO `ewmp_dosen` VALUES (3, 1, 'Adi Sucipto, S.ST, M.Tr.T', 1, 18.00, NULL, NULL, 6.15, 5.60, 1.50, 31.25, 15.63, NULL, '2024-10-28 01:03:34', '2024-10-28 01:03:34');
INSERT INTO `ewmp_dosen` VALUES (4, 1, 'Ahmad Fahriyannur Rosyady, S.Kom, M.MT', 1, 22.00, NULL, NULL, 2.40, 4.60, 1.75, 30.75, 15.37, NULL, '2024-10-28 01:04:13', '2024-10-28 01:04:13');
INSERT INTO `ewmp_dosen` VALUES (5, 1, 'Mochammad Rifki Ulil Albaab,S.T.,M.Tr.T', 1, 18.95, NULL, NULL, 3.69, 0.47, 7.00, 30.12, 15.06, NULL, '2024-10-28 01:04:57', '2024-10-28 01:04:57');
