-- ----------------------------
-- Records of dosen_pembimbing_ta
-- ----------------------------
INSERT INTO `dosen_pembimbing_ta` VALUES (1, 1, 'Rani Purbaningtyas, S.Kom, M.T', 10, NULL, NULL, '2024-10-27 21:14:36', '2024-10-27 21:14:36');
INSERT INTO `dosen_pembimbing_ta` VALUES (2, 1, 'Sholihah Ayu Wulandari, S.ST, M.Tr.T.', 10, NULL, NULL, '2024-10-27 21:15:35', '2024-10-27 21:15:35');
INSERT INTO `dosen_pembimbing_ta` VALUES (3, 1, 'Adi Sucipto, S.ST, M.Tr.T', 10, NULL, NULL, '2024-10-27 21:15:43', '2024-10-27 21:15:43');
INSERT INTO `dosen_pembimbing_ta` VALUES (4, 1, 'Ahmad Fahriyannur Rosyady, S.Kom, M.MT', 10, NULL, NULL, '2024-10-27 21:15:53', '2024-10-27 21:15:53');
INSERT INTO `dosen_pembimbing_ta` VALUES (5, 1, 'Mochammad Rifki Ulil Albaab, S.ST, M.Tr.T', 10, NULL, NULL, '2024-10-27 21:16:01', '2024-10-27 21:16:01');
