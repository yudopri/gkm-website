-- ----------------------------
-- Records of dosen_industri_praktisi
-- ----------------------------
INSERT INTO `dosen_industri_praktisi` VALUES (1, 1, 'Ahsanun Naseh Khudori, M.Kom', NULL, 'PT. Arkatama Multi Solusindo', 'S2', 'Digital Marketing', '<ul><li>BNSP Certificate of Competence the Senior Programmer</li><li>BNSP Certificate of Competence the Digital Marketing</li><li>Certificate of Competence the MikroTik Training for Advanced Class (MTCRE)</li><li>Xertificate of Competence the MikroTik Training for Fundamental Class (MTCNA)</li><li>Basic Instructional Technique Skilss Improvement Training (PEKERTI)</li></ul>', '<p>Etika Magang</p>', 20, NULL, '2024-10-29 23:28:37', '2024-10-29 23:39:50');
