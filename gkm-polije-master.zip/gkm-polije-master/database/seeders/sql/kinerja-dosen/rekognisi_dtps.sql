-- ----------------------------
-- Records of rekognisi_dtps
-- ----------------------------
INSERT INTO `rekognisi_dtps` VALUES (1, 1, 'Rani Purbaningtyas, S.Kom, M.T', 'Teknik Informatika', 'Reviewer jurnal JEECS Ubhara Surabaya mulai edisi Juni 2023', 'https://drive.google.com/drive/folders/1Yo51AD66bQ86HRwww8H5UiZdOCe_Y1LE?usp=drive_link', 'nasional', '2023', NULL, '2024-10-31 16:42:36', '2024-10-31 16:42:36');
INSERT INTO `rekognisi_dtps` VALUES (2, 1, 'Rani Purbaningtyas, S.Kom, M.T', 'Teknik Informatika', 'Reviewer jurnal INFOTEL IT TELKOM Purwokerto', 'https://drive.google.com/file/d/15JqCTb2qw86dhLWn1KeGftmj4WekU6Q_/view?usp=drive_link', 'nasional', '2023', NULL, '2024-10-31 16:45:37', '2024-10-31 16:45:37');
