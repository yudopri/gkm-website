<?php

namespace App\Http\Controllers\Api\KualitasPembelajaran;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class KepuasanMahasiswaController extends Controller
{
    //
}
